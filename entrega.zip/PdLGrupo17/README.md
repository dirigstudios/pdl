# Práctica PDL

## Cómo Inciarlo

1. Ir al directorio donde se encuentre el fichero pdl.jar
2. Abrir una terminal
3. Escribir el siguiente comando: java -jar pdl.jar fichero
	- Dicho fichero contendrá el código a procesar
4. Se generarán en la ruta donde se encuentre pdl.jar los ficheros de tokens, tabla de símbolos y parse.

### Créditos

Una obra de DiriG Studios (R) 2023. Todos los derechos reservados.

